<?php
        include "includes/sesionInicio.php";
?>

<!DOCTYPE html>
<html lang="en">



<?php
        include "includes/Encabezado.php";
?>
<body>
    <div class="wrapper">        
        <main>
            <nav class="menu-paginas">
                <a href="catalogo-productos-servicios.php">Catalogo de productos</a>
                <a href="ReiniciarBD.php">Reiniciar la Base de Datos</a>
                <a href="automatizacion.php">Registrar empresa</a>
                <a href="facturasAutomaticas.php">Generación de facturas</a>
            </nav> 
        </main>

    </div>

    <?php
        include "includes/PiePagina.php";
    ?>
</body>

</html>