
<div class = "anuncio">
<?php
    $conn = conectar();
    $sql = "SELECT * FROM Descuento";
    $resultado = $conn->query($sql);
    $query = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($query);
    $randomisa = rand(1,$count);
    if($resultado -> num_rows > 0){
        $img = "";
             while($row = $resultado->fetch_assoc()){
              if($randomisa == $row['ID']){
                $img = $row['imagen'];
              } 
             } 
?>
            <img class= "imganuncio" src="<?php echo $img; ?>" >   
<?php         
     }
     cerrar($conn);
?>
</div>

