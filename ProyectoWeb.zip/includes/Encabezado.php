
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KeysForGeeks</title>
    <link rel="stylesheet" href="estilos.css" />
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>

<header>
    <a href="index.php"><img width="200px" src="img/logo.jpg" alt="logo"></a>

        <div class="buscador">
                <input type="text" name="search" placeholder="Buscar..." class="src" autocomplete="off">

                    <!-- <input type="submit" value="buscar"> -->
        </div>  

        <div class="botones-header">
            <?php
                if(@$_SESSION['usuario']==null || $_SESSION['usuario']==''){
                    echo "<a href='Logueo.php' class='header-icon'>";
                }else{
                    echo "<a href='usuario.php' class='header-icon'>";    
                }
            ?>
            <i class='bx bxs-user'></i>
                    </a>"
            <a href='carrito.php' class="header-icon">
                <i class='bx bxs-cart'></i>
            </a>
        </div>
<?php
  include "includes/Conexion.php";
?>
</header>