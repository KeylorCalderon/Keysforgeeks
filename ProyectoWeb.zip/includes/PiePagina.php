
<footer id="contacto">
        <div class="contenedor footer-content">
            <div class="contact-us">
                <h2 class="brand">KeysForGeeks &copy;</h2>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quod, accusamus.</p>
            </div>
            <div class="social-media">
                <a href="./" class="social-meida-icon">
                    <i class='bx bxl-instagram'></i>
                </a>
                <a href="./" class="social-meida-icon">
                    <i class='bx bxl-facebook'></i>
                </a>
                <a href="./" class="social-meida-icon">
                    <i class='bx bxl-twitter'></i>
                </a>
                <a href="Contacto.php" class="social-meida-icon">
                    <i class='bx bxs-contact'></i>
                </a>
            </div>
        </div>
        <div class="line"></div>
</footer>

<script src="menu.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="CargarCatalogo.js"></script>
